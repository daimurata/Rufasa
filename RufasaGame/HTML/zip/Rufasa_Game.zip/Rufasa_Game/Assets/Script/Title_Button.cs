﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

/// <summary>
/// Title_Button【タイトル_ボタン】の点滅処理
/// </summary>
public class Title_Button : MonoBehaviour
{
    //点滅するテキスト
    public Text Start_Text;

    //点滅切替
    private bool Change = false;

    //α値【透明度】
    public float Alpha;

    //α値【透明度】スピード
    public float Alpha_Speed;

    /// <summary>
    /// 初期データ
    /// </summary>
    void Start()
    {
        
    }

    /// <summary>
    /// 常に更新
    /// </summary>
    void Update()
    {
        //α値【透明度】の更新
        Start_Text.GetComponent<Text>().color = new Color(1,1,1,Alpha);

        //α値【透明度】の点滅処理
        Blink();
    }

    /// <summary>
    /// α値【透明度】の点滅処理
    /// </summary>
   private void Blink()
    {
        //切替（加算）
        if (Change==true)
        {
            //α値【透明度】に加算
            Alpha += Alpha_Speed * Time.deltaTime;

            //α値【透明度】が1.0以上になったら
            if (Alpha>=1.0f)
            {
                //α値【透明度】を1.0fにする
                Alpha = 1.0f;

                //切替（減算）
                Change = false;
            }
        }
        //切替（減算）
        else if (Alpha<=0.0f)
        {
            //α値【透明度】が0.0にする
            Alpha = 0.0f;

            //切替(加算)
            Change = true;
        }
    }

    /// <summary>
    /// ゲームシーンに行く
    /// </summary>
    public void Click_GO()
    {
        //ゲームシーンへ移動
        SceneManager.LoadScene("Game");
    }
}
