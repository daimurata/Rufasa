﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Title【タイトル】画面のRufasa【ルファサ】にアタッチ【追加】
/// </summary>
public class Title_Rufasa : MonoBehaviour
{
    //移動
    private float Mov;

    //スピード
    private float Speed = 1;

    //移動範囲の最大
    private float Max_Mov = 0.5f;

    //移動範囲の最小
    private float Min_Mov = -2.5f;

    //上下運動切替
    private bool Change = true;
    
    /// <summary>
    /// 初期データ
    /// </summary>
    void Start()
    {
        
    }

    /// <summary>
    /// 常に更新
    /// </summary>
    void Update()
    {
        //上下移動
        Loop_Mov();
    }

    /// <summary>
    /// 上下移動
    /// </summary>
    private void Loop_Mov()
    {
        //代入してコードを短くする
        Vector2 Pos = transform.position;

        //上に動く
        if (Change==true)
        {
            //毎フレーム【時間】で動く
            Pos.y += Speed * Time.deltaTime;

            //移動範囲以上に行ったら【最大】
            if (Pos.y>=Max_Mov)
            {
                //切替
                Change = false;
            }
        }
        //下に動く
        else if (Change==false)
        {
            //時間で動く
            Pos.y -= Speed * Time.deltaTime;

            //移動範囲以下に行ったら【最小】
            if (Pos.y<=Min_Mov)
            {
                //切替
                Change = true;
            }
        }
        transform.position = Pos;

    }
}
