﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 弾のコントロール
/// </summary>
public class Bullet_Player : MonoBehaviour
{
    //弾の速さ
    public float Mov_X;

    //弾を消す場所
    public float Range=9.46f;

    //弾のHP
    public int HP = 1;

    /// <summary>
    /// 初期データ
    /// </summary>
    void Start()
    {

    }

    /// <summary>
    /// 更新データ
    /// </summary>
    void Update()
    {
        //X側方向に進む→
        transform.Translate(Mov_X, 0f, 0f);

        //【弾のポジション】のコードを短くする
        float Des_Bullet = transform.position.x;

        //X方向に一定まで進んだら
        if (Des_Bullet>=Range||HP<=0)
        {
            //弾自信を消す
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// 弾に衝突した判定
    /// </summary>
    private void OnTriggerStay2D(Collider2D collider)
    {
        //小さな敵に弾が当たったら
        if (collider.name.Contains("Small_Enemy")||
                //中ボスに触れたとき
                collider.name.Contains("Enemy_Mini") ||
                //大ボスに触れたとき
                collider.name.Contains("Boss_Enemy"))
        {
            //弾HP減算
            HP--;
        }
        //敵の弾がプレイヤーの弾に当たったら
        if (collider.name.Contains("Enemy_Bullet Variant"))
        {
            //触れた敵の弾を削除する
            Destroy(collider.gameObject);

            //弾を削除する
            HP--;
        }
           
    }
}
